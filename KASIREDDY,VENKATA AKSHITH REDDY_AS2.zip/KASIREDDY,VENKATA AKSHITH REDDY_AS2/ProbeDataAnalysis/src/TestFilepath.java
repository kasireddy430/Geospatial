import java.io.File;

public class TestFilepath {

    public static void main(String[] args) {
        //File file = new File("C:\\Users\\Nikhil\\Desktop\\gre\\illinois\\CS513\\Assignment2\\Partition6467LinkData.csv");
        File file1 = new File("C:\\Users\\Nikhil\\Desktop\\gre\\illinois\\CS513\\Assignment2\\Partition6467ProbePoints.csv");
        System.out.println(file1.getName());
    }
}
